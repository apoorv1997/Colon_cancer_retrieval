# Image retrieval using Siamese SiameseNetwork

For image retrieval use `net.py` and the read function is present in `MLView()` function in `view.py`
